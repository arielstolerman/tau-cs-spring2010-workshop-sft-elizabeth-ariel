% environment setup for SFT usage
% change the path to the path of sft_lib.jar
javaaddpath('/specific/a/home/cc/students/cs/arielst1/sft/FINAL/sft_lib.jar')
